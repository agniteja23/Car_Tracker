﻿namespace CarApiClient
{
    public class Events
    {
        //Delegates adn Events
        public delegate void notify(string message);
        public event notify Event;

        public void startEvent(string message)
        {


            Event?.Invoke(message);
        }
    }
}