﻿using CarApiClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Net.NetworkInformation;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace CarApiClient
{
    public class Tasks : Events
    {
        string msg = "";

        public static HttpClient connect()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("https://localhost:7024/");

            return client;

        }



        public async Task insert()
        {
            HttpClient client = connect();
            var cars = client.GetFromJsonAsync<Car[]>("api/cars");

            Console.WriteLine("Enter Car Name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter manufacturing Year: ");
            int year = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Company: ");
            string company = Console.ReadLine();
            Console.WriteLine("Enter Model Number: ");
            string model_number = Console.ReadLine();
            Console.WriteLine("Enter car Status: ");
            string status = Console.ReadLine();

            var newCar = new Car { name=name, Year=year, company=company, status = status, Model=model_number };
            var response = await client.PostAsJsonAsync("api/cars", newCar);

            if (response.IsSuccessStatusCode)
            {
                var createdCar = await response.Content.ReadFromJsonAsync<Car>();
                msg = $"\nNew car added with Name: {createdCar.name}";
            }
            else
            {
                msg = $"Failed to Add car.";
            }

            startEvent(msg);
            client.Dispose();
        } //Working
        public async Task GetCarsByYear(int year)  //not working
        {
            HttpClient client = connect();
            var cars = await client.GetFromJsonAsync<Car[]>($"api/cars/{year}");

            if (!cars.Any())
            {
                string msg = $"Zero cars present for the entered year:{year}";  //Use of Event
                startEvent(msg);
            }
            else
            {
                Console.WriteLine("             Car Details:                ");
                foreach (var car in cars) { car.display(); }
            }
            client.Dispose();

        }

        public async Task removeCar(string name)
        {
            HttpClient client = connect();
            var cars = client.GetFromJsonAsync<Car[]>("api/cars");

            var response = await client.DeleteAsync($"api/cars/{name}");

            if (response.IsSuccessStatusCode)
            {

                msg=$"{name} deleted successfully";
            }
            else
            {
                msg="Failed to Delete car as it is not found.";
            }

            startEvent(msg);
            client.Dispose();
        }



        public async Task details()
        {
            HttpClient client = connect();
            var cars = await client.GetFromJsonAsync<Car[]>("api/cars");

            if (!cars.Any())
            {
                string msg = "There are no cars present in the inventory";
                startEvent(msg);
            }
            else
            {
                Console.WriteLine("             Car Details:                ");
                foreach (var c in cars)
                {
                    c.display();
                }
            }
            client.Dispose();
        }

        public async Task updateStatus(string status, string carName)
        {
            HttpClient client = connect();
            var cars = await client.GetFromJsonAsync<Car[]>("api/cars");
            var updatedcar = cars.FirstOrDefault(c => c.name.Equals(carName, StringComparison.OrdinalIgnoreCase));
            bool update = true;
            if (updatedcar == null)
            {

                msg = "No car found with the given name to update the status";
            }
            else
            {
                string stat = status.ToLower();
                switch (stat)
                {
                    case "sold":
                    case "reserved":
                    case "available":
                        if (!updatedcar.status.Equals(status, StringComparison.OrdinalIgnoreCase))
                        {
                            updatedcar.status = status;
                        }
                        else
                        {
                            msg = $"Car is already {status}";
                            update = false;
                        }
                        break;

                    default:
                        msg = "Invalid status code";
                        update = false;
                        break;
                }


            }

            if (update != false)
            {
                var response = await client.PutAsJsonAsync<Car>($"api/cars/update{carName}", updatedcar);

                if (response.IsSuccessStatusCode)
                {
                    msg="Update successful.";
                }
                else
                {
                    msg=$"Update failed. Status code: {(int)response.StatusCode} - {response.ReasonPhrase}";
                }

            }

            startEvent(msg);
        }
           
            
            
       

    }
}

     
    

