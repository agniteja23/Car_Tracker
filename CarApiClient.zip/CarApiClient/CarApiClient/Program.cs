﻿using System;
using System.Net.Http;
using System.Net.Http.Json;
using System.Runtime.ConstrainedExecution;
using System.Threading.Tasks;

namespace CarApiClient
{
    class Program
    {
        static async Task Main(string[] args)
        {
           Car c = new Car();
            EventHandlers eventHandlers = new EventHandlers();
            c.Event+=eventHandlers.handleNotificationEvent;

            //Since car inherits tasks and tasks inherit Events class,
            //we can directly use car object to access Events class parameter or methods.
            Console.WriteLine("====CAR TRACKER====");
            try
            {

                int option = 0;
                while (option!=6)
                {
                    try
                    {
                        Console.WriteLine("Choose one of the following:\n1.Add Car\n2.View by Year\n3.Remove Car\n4.View All\n5.Update Status\n6.EXIT");
                        option = int.Parse(Console.ReadLine());
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("Please eneter a valid number between 1 to 6 :)");
                    }
                    
                    switch (option) {

                        case 1:    //Insert a car //POST
                            await c.insert();
                            break;

                        case 2:  //Get car by Year
                            
                                Console.WriteLine("Which year car details you want?: ");
                                int y = int.Parse(Console.ReadLine());
                            await c.GetCarsByYear(y);
                            break;

                        case 3:  //Delete Car
                            Console.WriteLine("Enter name of the car you want to remove: ");
                            String cname = Console.ReadLine();
                           await c.removeCar(cname);
                            break;
                        case 4: //View All
                            await c.details();
                            break;

                        case 5: //update //put
                            Console.WriteLine("Enter name of the car you want to update the status for:");
                            string carName = Console.ReadLine();
                            Console.WriteLine("Enter updated car status:");
                            String cstatus= Console.ReadLine();

                            await c.updateStatus(cstatus, carName);
                            break;
                        case 6:
                            return;
                            
                            default: Console.WriteLine("Invalid option");break;

                    }
                }

                    // GET all cars
                   // var cars = await client.GetFromJsonAsync<Car[]>("api/cars")

/*
                // POST a new car
                var newCar = new Car { Make = "Ford", Model = "Focus", Year = 2022 };
                var response = await client.PostAsJsonAsync("api/cars", newCar);

                if (response.IsSuccessStatusCode)
                {
                    var createdCar = await response.Content.ReadFromJsonAsync<Car>();
                    Console.WriteLine($"\nNew car created with ID: {createdCar.Id}");
                }
                else
                {
                    Console.WriteLine("Failed to create car.");
                }
*/
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }
    }
}
