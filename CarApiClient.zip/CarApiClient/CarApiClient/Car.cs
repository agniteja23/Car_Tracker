﻿using System.Net.NetworkInformation;

namespace CarApiClient
{

    public class Car:Tasks
    {
        public string name { get; set; }
        public string company { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public string status { get; set; }

        public void display()
        {
            Console.WriteLine("\n============================================\n");
            Console.WriteLine($"Car Name:{name}\nManufacturing Year: {Year}\nCompany: {company}\nModel Number: {Model}\nStatus: {status}\n");
        }
    }

}
