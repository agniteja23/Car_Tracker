﻿namespace CARAPI
{

    public class Car
    {
        public string name { get; set; }
        public string company { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public string status { get; set; }
    }

}
