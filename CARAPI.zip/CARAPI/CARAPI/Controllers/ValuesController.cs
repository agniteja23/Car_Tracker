﻿using CARAPI;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class CarsController : ControllerBase
{
    [HttpGet]
    public ActionResult<IEnumerable<Car>> Get()
    {
        var cars = CarFileHelper.LoadCars();
        return Ok(cars);
    }

    [HttpGet("{Year}")]
    public ActionResult<Car> Get(int Year)
    {
        var cars = CarFileHelper.LoadCars();
        var car = cars.Where(c => c.Year == Year);
        if (car == null) return NotFound();
        return Ok(car);
    }

    [HttpPost]
    public ActionResult<Car> Post(Car car)
    {
        var cars = CarFileHelper.LoadCars();
        
        cars.Add(car);
        CarFileHelper.SaveCars(cars);
        return CreatedAtAction(nameof(Get), new { year = car.Year }, car);
    }

    [HttpPut("update{name}")]
    public IActionResult Put(string name, Car updatedCar)
    {
        var cars = CarFileHelper.LoadCars();
        var car = cars.FirstOrDefault(c => c.name.Equals(name, StringComparison.OrdinalIgnoreCase));
        if (car == null) return NotFound();

        car.name=updatedCar.name;
        car.company = updatedCar.company;
        car.Model = updatedCar.Model;
        car.Year = updatedCar.Year;
        car.status=updatedCar.status;

        CarFileHelper.SaveCars(cars);
        return Content($"{name} updated successfully");
    }

    [HttpDelete("{name}")]
    public IActionResult Delete(string name)
    {
        var cars = CarFileHelper.LoadCars();
        var car = cars.FirstOrDefault(c => c.name.Equals(name, StringComparison.OrdinalIgnoreCase));
        if (car == null) return NotFound();

        cars.Remove(car);
        CarFileHelper.SaveCars(cars);
        return Content($"{name} Deleted Successfully");
    }
}
