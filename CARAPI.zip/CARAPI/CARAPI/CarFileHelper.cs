﻿using CARAPI;
using System.Text.Json;

public static class CarFileHelper
{
    private static readonly string filePath = @"C:\Users\GBO3KOR\source\repos\CARAPI\CARAPI\cars.json";

    public static List<Car> LoadCars()
    {
        if (!File.Exists(filePath)) return new List<Car>();

        var json = File.ReadAllText(filePath);
        return JsonSerializer.Deserialize<List<Car>>(json) ?? new List<Car>();
    }

    public static void SaveCars(List<Car> cars)
    {
        var json = JsonSerializer.Serialize(cars, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(filePath, json);
    }
}
