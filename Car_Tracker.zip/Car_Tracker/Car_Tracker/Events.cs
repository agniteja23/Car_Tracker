﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car_Tracker
{
    public class Events
    {
        //Delegates adn Events
        public delegate void notify(string message);
        public event notify Event;

        public void startEvent(string message) {


            Event?.Invoke(message);
        }
    }
}
