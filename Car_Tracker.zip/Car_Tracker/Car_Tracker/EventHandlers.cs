﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car_Tracker
{
    public class EventHandlers
    {

        public void handleNotificationEvent(string msg) { 
        
        Console.WriteLine("Notification: "+msg); 
        }
    }
}
